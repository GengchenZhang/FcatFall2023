from rdflib import Graph, RDFS
import pathlib
import pandas as pd
import dash_daq as daq
import math

import dash
from dash import dcc, html, dash_table, Input, Output, State
import dash_bootstrap_components as dbc
from dash_bootstrap_templates import ThemeChangerAIO
import dash_cytoscape as cyto

import rdflib
from rdflib import Graph, URIRef
from rdflib.namespace import RDFS
import networkx as nx

import plotly.express as px

from utilities.ont import get_cytoscape_elements
from utilities.ont import get_sparql_query_results

# --------------------------------------------------
# ontology configuration details
#
# location of directory 'data'
BASE_PATH = pathlib.Path(__file__).parent.resolve()
DATA_PATH = BASE_PATH.joinpath("data").resolve()

# ontology names
ontologies_df = pd.read_csv(DATA_PATH.joinpath("ontologies.csv"))
ontology_names_as_list = ontologies_df["Name"].unique()

# ontology specific sparql queries
queries_list = pd.DataFrame()
df_query_results = ontologies_df.copy()

# ontology specific cytoscape data elements
ontology_view_elements = []

# ticker names
tickers_as_list = ['BTC', 'ETH', 'BNB', 'XRP']

# --------------------------------------------------
# bootstrap formatting
#
# format colors: primary, secondary, success, info, warning, danger, light, dark, link
# p-2 mb-2 text-left
title_format = "bg-transparent text-primary text-left"
footer_format = "bg-transparent text-primary text-left"
accordian_format = "bg-dark text-secondary text-center"
accordian_item_format = "bg-light text-link text-center"
textarea_format = "bg-light text-link text-left"
tab_active_format = "bg-transparent text-secondary text-center"
tab_inactive_format = "bg-light text-primary text-center"
view_control_panel_format = "bg-light text-primary text-center"

# --------------------------------------------------
# Functions to Load and Process OWL File
#


def create_cytoscape_graph(g, name, descriptions):
    elements = []
    for subj, pred, obj in g:
        # Simplify URIs for readability
        subj_label = str(subj).split('#')[-1]
        obj_label = str(obj).split(
            '#')[-1] if isinstance(obj, rdflib.term.URIRef) else str(obj)

        # Add nodes and edges for subClassOf relationships
        if pred == RDFS.subClassOf:
            subj_tooltip = descriptions.get(
                subj_label, 'No descriptions available')
            obj_tooltip = descriptions.get(
                obj_label, 'No descriptions available')

            subj_name = name.get(subj_label, subj_label)
            obj_name = name.get(obj_label, obj_label)

            elements.extend([
                {'data': {'id': subj_label, 'label': subj_name, 'tooltip': subj_tooltip}},
                {'data': {'id': obj_label, 'label': obj_name, 'tooltip': obj_tooltip}},
                {'data': {'source': subj_label, 'target': obj_label}}
            ])
    return elements


def load_ontology_graph(ontology_name, description_name):

    owl_file_path = DATA_PATH.joinpath("defi").joinpath(f"{ontology_name}.owl")
    g = Graph()
    g.parse(owl_file_path)

    # Load descriptions from a CSV file
    node_descriptions_df = pd.read_csv(
        DATA_PATH.joinpath("defi").joinpath(f"{description_name}.csv"))
    # Convert DataFrame to a dictionary for faster lookups
    node_descriptions = dict(
        zip(node_descriptions_df['node_id'], node_descriptions_df['description']))

    node_name = dict(
        zip(node_descriptions_df['node_id'], node_descriptions_df['node_name']))

    return create_cytoscape_graph(g, node_name, node_descriptions)


ontology_graph_elements = load_ontology_graph("defi", "descriptions")
# --------------------------------------------------
# instantiate the dash server
#
dbc_css = "https://cdn.jsdelivr.net/gh/AnnMarieW/dash-bootstrap-templates/dbc.min.css"
external_scripts = [
    dbc.themes.SKETCHY, dbc_css,
    'https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.19.0/cytoscape.min.js',  # Cytoscape core
    'https://unpkg.com/layout-base@1.0.0/layout-base.min.js',  # Layout base
    'https://unpkg.com/cose-base@1.0.0/cose-base.min.js',  # Cose base
    'https://unpkg.com/cytoscape-cose-bilkent@4.1.0/cytoscape-cose-bilkent.js'  # Cose-bilkent
]
app = dash.Dash(__name__, external_stylesheets=external_scripts)
app.config.suppress_callback_exceptions = True

####################################################################################################################
# top container
#
top_container = \
    dbc.Row(
        [
            dbc.Col(
                [

                    html.H1("Semantic Web Dashboard", style={
                            "font-weight": "bold"}, className=title_format),
                ],
                width=10,
            ),
        ]
    )

####################################################################################################################
# bottom container
#
bottom_container = \
    dbc.Row(
        [
            dbc.Col(
                [
                    html.Img(src='/assets/brandeis-logo.png',
                             style={'height': '15%'}),
                ],
                width=2,
            ),
            dbc.Col(
                [
                    html.H6(
                        "Developed by Brandeis University International Business School",
                        style={'marginTop': '20px', 'fontSize': '20px'},
                        className=f"{footer_format} mt-3"
                    )
                ],
                width=10,
            ),
        ]
    )

####################################################################################################################
# sidebar container
#
sidebar_container = html.Div(
    [
        dbc.Accordion(
            [
                dbc.AccordionItem(
                    [
                        html.P("Select Ontology",
                               className=accordian_item_format,
                               style={"font-weight": "bold"}),
                        dcc.Dropdown(
                            id="ontology-select",
                            placeholder="Select",
                            options=[{"label": i, "value": i}
                                     for i in ontology_names_as_list],
                        ),
                        html.Br(),
                        html.P("Description",
                               className=accordian_item_format,
                               style={"text-decoration": "underline", "font-weight": "bold"}),
                        dcc.Markdown(
                            id="ontology-description",
                            children=[],
                            className=accordian_item_format
                        ),
                        html.Br(),
                        html.P("Endpoint",
                               className=accordian_item_format,
                               style={"text-decoration": "underline", "font-weight": "bold"}),
                        dcc.Markdown(
                            id="ontology-endpoint",
                            children=[],
                            className=accordian_item_format
                        ),
                        html.Br(),
                        html.P("Select SPARQL Query",
                               className=accordian_item_format,
                               style={"font-weight": "bold"}),
                        dcc.Dropdown(
                            id="sparql-query-select",
                            disabled=True,
                            options=[{"label": i, "value": i}
                                     for i in ontology_names_as_list],
                        ),
                        html.Br(),
                        html.Div(
                            id="submit-button-div",
                            children=[
                                dbc.Button(
                                    id="submit-button",
                                    children="Submit Query",
                                    n_clicks=0,
                                    disabled=True,
                                    style={'width': '100%'},
                                ),
                            ],
                        ),
                    ],
                    title="Ontology",
                    className=accordian_item_format,
                ),
                dbc.AccordionItem(
                    [
                        ThemeChangerAIO(aio_id="theme"),
                    ],
                    title="Theme",
                    className=accordian_item_format
                ),
            ],
            start_collapsed=False, always_open=True, flush=True,
            className=accordian_format
        ),
    ],
)

####################################################################################################################
# body container
# view tab
#
body_container_view = \
    dbc.Row(
        [
            dbc.Col(
                [
                    html.Div(
                        [
                            html.Br(),
                            html.P("Control Panel",
                                   className=accordian_item_format),
                            dcc.Dropdown(
                                id='ontology-view-update-layout',
                                value='grid',
                                clearable=False,
                                options=[
                                    {'label': name.capitalize(), 'value': name}
                                    for name in ['random', 'grid', 'circle', 'concentric', 'breadthfirst']
                                ],
                            ),
                        ],
                    ),
                ],
                className=view_control_panel_format,
                width=1,
            ),
            dbc.Col(
                [
                    cyto.Cytoscape(
                        id='ontology-view',
                        elements=ontology_view_elements,
                        style={'width': '100%', 'height': '1000px'},
                    )
                ],
                width=10,
            ),
        ]
    )


@app.callback(
    Output('ontology-view', 'layout'),
    Input('ontology-view-update-layout', 'value'))
def update_layout(layout):
    return {'name': layout}


####################################################################################################################
# body container
# query tab
#
body_container_query = \
    html.Div(
        [
            dbc.Accordion(
                [
                    dbc.AccordionItem(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.P(" ",
                                                   className=accordian_item_format,
                                                   ),
                                        ],
                                        width=12,
                                    ),
                                ]
                            ),
                            dbc.Row(
                                [dbc.Col(
                                    [
                                        html.P("Select Cryptocurrency",
                                               className=accordian_item_format,
                                               style={
                                                   "font-weight": "bold"}
                                               ),
                                        dcc.Dropdown(
                                            id='crypto-select-dropdown',
                                            options=[
                                                {'label': crypto, 'value': crypto} for crypto in tickers_as_list],
                                            value=tickers_as_list,  # Default to all selected, or choose a subset
                                            multi=False  # Allows selecting multiple cryptocurrencies
                                        ),
                                    ],
                                    width=3,  # Adjust width as needed
                                    style={
                                        'background-color': 'var(--bs-light)',
                                        'border-style': 'solid',
                                        'border-width': 'thin'
                                    },
                                    className="mx-3",
                                ),
                                    dbc.Col(
                                        [
                                            html.P("Date Range",
                                                   className=accordian_item_format,
                                                   style={
                                                       "font-weight": "bold"}
                                                   ),
                                            dcc.DatePickerRange(
                                                id='date-range-picker-select',
                                                clearable=True,
                                                disabled=True,
                                            ),
                                        ],
                                        width=3,
                                        style={
                                            'background-color': 'var(--bs-light)',
                                            'border-style': 'solid',
                                            'border-width': 'thin'
                                        },
                                        className="mx-3",
                                ),
                                    dbc.Col(
                                        [
                                            html.P("Precision",
                                                   className=accordian_item_format,
                                                   style={
                                                       "font-weight": "bold"}
                                                   ),
                                            daq.NumericInput(
                                                id='precision-select',
                                                label="Number of Decimal Points",
                                                labelPosition='bottom',
                                                value=2,
                                                min=0,
                                                max=6,
                                                disabled=True
                                            ),
                                        ],
                                        width=2,
                                        style={
                                            'background-color': 'var(--bs-light)',
                                            'border-style': 'solid',
                                            'border-width': 'thin'
                                        },
                                        className="mx-3",
                                ),
                                    dbc.Col(
                                        [
                                            html.P("Select Graph Type",
                                                   className=accordian_item_format,
                                                   style={"font-weight": "bold"}),
                                            dcc.Dropdown(
                                                id="graph-type-dropdown",
                                                options=[
                                                    {'label': 'Line',
                                                        'value': 'line'},
                                                    {'label': 'Bar',
                                                        'value': 'bar'},
                                                    {'label': 'Scatter',
                                                        'value': 'scatter'},
                                                    {'label': 'Histogram',
                                                        'value': 'histogram'}
                                                ],
                                                # disabled=True,
                                                value='Select',
                                                clearable=False
                                            )
                                        ],
                                        width=2,
                                        style={
                                            'background-color': 'var(--bs-light)',
                                            'border-style': 'solid',
                                            'border-width': 'thin'
                                        },
                                        className="mx-3",
                                )
                                ],
                            )
                        ],
                        title="Parameters",
                    ),
                    dbc.AccordionItem(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.P("Text",
                                                   className=accordian_item_format,
                                                   style={
                                                       "font-weight": "bold"}
                                                   ),
                                            dcc.Textarea(
                                                id='sparql-query-text',
                                                value='',
                                                cols='4',
                                                disabled=True,
                                                style={'width': '100%',
                                                       'height': 200},
                                                className=textarea_format
                                            ),
                                        ],
                                        width=6,
                                    ),
                                    dbc.Col(
                                        [
                                            html.P("Template",
                                                   className=accordian_item_format,
                                                   style={
                                                       "font-weight": "bold"}
                                                   ),
                                            dcc.Textarea(
                                                id='sparql-query-template-text',
                                                value='',
                                                cols='4',
                                                disabled=True,
                                                style={'width': '100%',
                                                       'height': 200},
                                                className=textarea_format
                                            ),
                                        ],
                                        width=6,
                                    ),
                                ],
                            )
                        ],
                        title="Query",
                    ),
                    dbc.AccordionItem(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.P("Chart",
                                                   className=accordian_item_format,
                                                   style={
                                                       "font-weight": "bold"}
                                                   ),
                                            dcc.Graph(
                                                id="query-results-chart"
                                            )
                                        ],
                                        width=6,
                                    ),
                                    dbc.Col(
                                        [
                                            html.P("Table",
                                                   className=accordian_item_format,
                                                   style={
                                                       "font-weight": "bold"}
                                                   ),
                                            dash_table.DataTable(
                                                id='query-results-table',
                                                data=df_query_results.to_dict(
                                                    'records'),
                                                columns=[{'id': c, 'name': c}
                                                         for c in ontologies_df.columns],

                                                page_current=0,
                                                page_size=25,
                                                fixed_rows={'headers': True},

                                                style_cell={
                                                    'textAlign': 'left'},
                                                style_as_list_view=True,

                                                row_deletable=False,
                                                editable=False,
                                                filter_action="native",
                                                sort_action="native",
                                                style_table={
                                                    "overflowX": "auto", 'overflowY': 'auto'},
                                                export_format="csv",
                                            )
                                        ],
                                        width=6,
                                    ),
                                ],
                            )
                        ],
                        title="Query Results",
                    ),

                ],
                start_collapsed=False, always_open=True, flush=True,
            ),
        ],
    )


####################################################################################################################
# body container
# ontology tab
#
body_container_ontology = \
    dbc.Row(
        [
            dbc.Col(
                [
                    # Tooltip container
                    html.Div(id='cytoscape-tooltip'),

                    # Cytoscape Graph container
                    cyto.Cytoscape(
                        id='ontology-visualization',
                        elements=ontology_graph_elements,
                        style={'width': '100%', 'height': '1000px'},
                        layout={'name': 'cose',
                                'nodeRepulsion': 1000000,
                                'idealEdgeLength': 100}
                    ),
                ],
                width=12
            )
        ],
    )


@app.callback(
    Output('cytoscape-tooltip', 'children'),
    [Input('ontology-visualization', 'tapNodeData')]
)
def display_tooltip(data):
    if data:
        # Create a tooltip div
        tooltip_style = {
            'position': 'absolute',
            'border': '1px solid black',
            'borderWidth': '1px',
            'padding': '10px',
            'backgroundColor': 'white',
            'left': '0%',
            'top': '5%',
            'zIndex': 100,   # Ensure the tooltip is on top of other elements
            'width': '250px',
            'height': '155px',
            'overflow': 'auto',  # Allows scrolling if content exceeds the box size
            'wordWrap': 'break-word',  # Ensures long words do not overflow
            # Includes padding and border in the element's total width and height
            'boxSizing': 'border-box',
            'textAlign': 'left'  # Aligns text to the left
        }
        # Combine the node label and description
        tooltip_content = html.Div([
            html.H5(data['label']),  # Display the node name in a header
            html.P(data['tooltip'])  # Display the description in a paragraph
        ])

        return html.Div(
            tooltip_content,
            style=tooltip_style
        )

    # Return an empty div if no data is passed
    return html.Div(style={'display': 'none'})


####################################################################################################################
# body container
# covariance tab
#
body_contianer_correlation = html.Div(
    [
        html.Div(
            [
                dcc.Dropdown(
                    id='crypto-select-dropdown-1',
                    options=[{'label': crypto, 'value': crypto}
                             for crypto in tickers_as_list],
                    value='BTC',  # Default to BTC
                    clearable=False
                ),
                dcc.Dropdown(
                    id='crypto-select-dropdown-2',
                    options=[{'label': crypto, 'value': crypto}
                             for crypto in tickers_as_list],
                    value='BTC',  # Default to BTC
                    clearable=False
                )
            ],
            style={'width': '50%', 'display': 'inline-block'}
        ),
        dcc.Graph(id='correlation-heatmap')
    ]
)


####################################################################################################################
# body container
#

tab_view = dbc.Tab(
    body_container_view, label="View",
    label_class_name=tab_inactive_format,
    active_label_class_name=tab_active_format,
)
tab_query = dbc.Tab(
    body_container_query, label="Query",
    label_class_name=tab_inactive_format,
    active_label_class_name=tab_active_format,
)
tab_ontology = dbc.Tab(
    body_container_ontology, label="Ontology",
    label_class_name=tab_inactive_format,
    active_label_class_name=tab_active_format,
)
tab_correlation = dbc.Tab(
    body_contianer_correlation, label="Correlation",
    label_class_name=tab_inactive_format,
    active_label_class_name=tab_active_format,
)
body_container = dbc.Card(
    dbc.Tabs([tab_query, tab_correlation, tab_view, tab_ontology])
)

####################################################################################################################
# layout
#
app.layout = dbc.Container(
    [
        dbc.Row(
            top_container,
            className='mb-4',
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        sidebar_container,
                    ],
                    width=2,
                    className='mb-4',
                ),
                dbc.Col(
                    [
                        body_container,
                    ],
                    width=10,
                ),
            ],
            className='mb-4',
        ),
        bottom_container,
    ],
    fluid=True,
    className='py-4',
)


####################################################################################################################
# callbacks
#
@app.callback(
    Output("ontology-description", "children"),
    Output("ontology-endpoint", "children"),
    Output("sparql-query-select", "options"),
    Output("sparql-query-select", "disabled"),
    [Input("ontology-select", "value")]
)
def ontology_select_dropdown_selected(ontology_selected):
    if ontology_selected is None:
        return '', '', [{"label": i, "value": i} for i in ontology_names_as_list], True

    # get attributes regarding the selected ontology
    df = ontologies_df.query(f'Name == "{ontology_selected}"')
    ontology_description = df['Description'].unique()[0]
    ontology_endpoint = df['Endpoint'].unique()[0]
    sparql_query_file = df['Sparql'].unique()[0]
    sparql_query_df = pd.read_csv(DATA_PATH.joinpath(sparql_query_file))
    query_name_list = sparql_query_df['Name'].unique()
    sparql_query_options = []
    for q in query_name_list:
        sparql_query_options.append({'label': q, 'value': q})

    return ontology_description, ontology_endpoint, sparql_query_options, False


@app.callback(
    Output("sparql-query-template-text", "value"),
    Output("sparql-query-template-text", "disabled"),
    Output("submit-button", "disabled"),
    Output("date-range-picker-select", "disabled"),
    Output("precision-select", "disabled"),
    [Input("sparql-query-select", "value")],
    [State("ontology-select", "value")]
)
def sparql_query_select_dropdown_selected(query_selected, ontology_selected):
    if ontology_selected is None or query_selected is None:
        return ('', True, True,
                True,
                True,
                )

    df = ontologies_df.query(f'Name == "{ontology_selected}"')
    sparql_query_file = df['Sparql'].unique()[0]
    sparql_query_df = pd.read_csv(DATA_PATH.joinpath(sparql_query_file))
    sparql_query_df.query(f'Name == "{query_selected}"', inplace=True)
    sparql_query_template = sparql_query_df['Sparql'].unique()[0]

    # determine which of the parameters control are needed for this query

    return (sparql_query_template, False, False,
            False,
            False)


@app.callback(
    Output("sparql-query-text", "value"),
    Output("sparql-query-text", "disabled"),
    Output("query-results-table", "data"),
    Output("query-results-table", "columns"),
    Output("ontology-view", "elements"),
    Output("query-results-chart", "figure"),
    [Input("submit-button", "n_clicks"),
     Input("graph-type-dropdown", "value"),
     Input("crypto-select-dropdown", "value")],
    [State("ontology-endpoint", "children"),
     State("sparql-query-template-text", "value"),
     State("date-range-picker-select", "start_date"),
     State("date-range-picker-select", "end_date"),
     State("precision-select", "value")
     ]
)
def submit_button_selected(n_clicks, graph_type, selected_crypto, ontology_endpoint, sparql_query_template,
                           start_date, end_date, precision):
    import plotly.express as px
    figure = px.line(x=['a', 'b', 'c', 'd'], y=[
                     1, 2, 2, 1], title='placeholder figure')

    if n_clicks == 0 or ontology_endpoint is None or sparql_query_template is None:
        data = ontologies_df.to_dict('records')
        columns = [{'id': c, 'name': c} for c in ontologies_df.columns]
        return '', True, data, columns, ontology_view_elements, figure

    sparql_query_text = sparql_query_template

    # replace according to meta tags

    start_tag, end_tag = "<<", ">>"
    start_index = 0
    while True:
        idx_1 = sparql_query_template.find(start_tag, start_index)
        if idx_1 == -1:
            break
        idx_2 = sparql_query_template.find(
            end_tag, start_index + len(start_tag))
        if idx_2 == -1:
            break
        tag = sparql_query_template[idx_1 + len(start_tag): idx_2]
        name_value = tag.split(':')

        if name_value[1].strip() == 'start_date':
            sparql_query_text = sparql_query_text.replace(
                name_value[0], start_date)
        elif name_value[1].strip() == 'end_date':
            sparql_query_text = sparql_query_text.replace(
                name_value[0], end_date)
        elif name_value[1].strip() == 'precision':
            sparql_query_text = sparql_query_text.replace(
                'precision', str(math.pow(10, precision)))
        start_index = idx_2

    results_table, results_columns, results_df = get_sparql_query_results(
        ontology_endpoint, sparql_query_text)

    filtered_columns = set(['date'])
    filtered_columns.update(
        col for col in results_df.columns if selected_crypto in col)

    # Convert the set back to a list and create the filtered DataFrame
    filtered_df = results_df[list(filtered_columns)].copy()

    for col in filtered_df.columns:
        if col == 'date':
            continue
        ma_col_name = col + '_20d_ma'
        diff_col_name = col + '_diff'
        filtered_df.loc[:, ma_col_name] = filtered_df[col].rolling(
            window=20).mean()
        filtered_df.loc[:, diff_col_name] = filtered_df[col].astype(
            float) - filtered_df[ma_col_name].astype(float)

    data = []
    for col in filtered_df.columns:
        if col == 'date':
            continue

        # Plot for daily price
        if '_20d_ma' not in col and '_diff' not in col:
            daily_price_trace = dict(
                type=graph_type,  # Assuming you want a line plot for daily prices
                x=filtered_df['date'],
                y=filtered_df[col],
                name=col,
            )
            data.append(daily_price_trace)

        # Corresponding 20-day moving average plot
        if '_20d_ma' in col:
            moving_avg_trace = dict(
                type="line",  # Line plot for moving averages
                x=filtered_df['date'],
                y=filtered_df[col],
                name=col,
                # line=dict(dash='dash')  # Dashed line for the moving average
            )
            data.append(moving_avg_trace)

        # Corresponding difference plot
        if '_diff' in col:
            colors = ['green' if diff >
                      0 else 'red' for diff in filtered_df[col]]
            diff_trace = dict(
                type="bar",  # Bar plot for the difference
                x=filtered_df['date'],
                y=filtered_df[col],
                name=col,
                marker=dict(color=colors)
            )
            data.append(diff_trace)

    layout = {"title": "Results", "dragmode": "select",
              "showlegend": True, "autosize": True}
    figure = dict(data=data, layout=layout)

    cytoscape_elements = get_cytoscape_elements(ontology_endpoint)

    return sparql_query_text, False, results_table, results_columns, cytoscape_elements, figure


@app.callback(
    Output("correlation-heatmap", "figure"),
    [Input('crypto-select-dropdown-1', 'value'),
     Input('crypto-select-dropdown-2', 'value')],
    [State("ontology-endpoint", "children"),
     State("sparql-query-template-text", "value"),
     State("date-range-picker-select", "start_date"),
     State("date-range-picker-select", "end_date"),
     State("precision-select", "value")]
)
def update_correlation_heatmap(crypto1, crypto2, ontology_endpoint, sparql_query_template, start_date, end_date, precision):
    if not crypto1 or not crypto2 or crypto1 == crypto2:
        return px.imshow(pd.DataFrame(), title='Select two different cryptocurrencies')

    sparql_query_text = sparql_query_template

    start_tag, end_tag = "<<", ">>"
    start_index = 0
    while True:
        idx_1 = sparql_query_template.find(start_tag, start_index)
        if idx_1 == -1:
            break
        idx_2 = sparql_query_template.find(
            end_tag, start_index + len(start_tag))
        if idx_2 == -1:
            break
        tag = sparql_query_template[idx_1 + len(start_tag): idx_2]
        name_value = tag.split(':')

        if name_value[1].strip() == 'start_date':
            sparql_query_text = sparql_query_text.replace(
                name_value[0], start_date)
        elif name_value[1].strip() == 'end_date':
            sparql_query_text = sparql_query_text.replace(
                name_value[0], end_date)
        elif name_value[1].strip() == 'precision':
            sparql_query_text = sparql_query_text.replace(
                'precision', str(math.pow(10, precision)))
        start_index = idx_2

    results_table, results_columns, results_df = get_sparql_query_results(
        ontology_endpoint, sparql_query_text)

    filtered_columns = set(['date'])
    filtered_columns.update(
        col for col in results_df.columns if crypto1 or crypto2 in col)

    # Convert the set back to a list and create the filtered DataFrame
    correlation_df = results_df[list(filtered_columns)].copy()

    # correlation_df = results_df[crypto1, crypto2]
    corr = correlation_df.corr()

    fig = px.imshow(corr,
                    labels=dict(x="Cryptocurrency",
                                y="Cryptocurrency", color="Correlatioin"),
                    title=f"Correlation between {crypto1} and {crypto2}")
    return fig


##############################################
# Run the server
#
if __name__ == "__main__":
    app.run_server(debug=True)
